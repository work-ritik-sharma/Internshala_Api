require("dotenv").config({path:'./.env'});
const express = require("express");
const app = express();
PORT = 8080;
//logger
const logger = require("morgan");
app.use(logger("tiny"));



app.use("/", require("./routes/indexRouter"));

//error handling
const ErrorHandler = require("./utiles/ErrorHandler");

app.all("*" , (req,res,next)=>{
    next(new ErrorHandler (`Requested URL Not Found ${req.url}`),404);

});
app.use(GentatedErrors);


app.listen(PORT, console.log("server running on port 3030 "));