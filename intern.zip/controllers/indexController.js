exports.homepage = (res, req, next) => {
    req.json({ message: "homepage" });
};