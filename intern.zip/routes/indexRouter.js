const express = require("express");
const { homepage } = require("../controllers/indexController");
const router = express.Router();
// const {homepage} = require("../controllers/indexController");

router.get("/",
homepage
);


module.exports = router;